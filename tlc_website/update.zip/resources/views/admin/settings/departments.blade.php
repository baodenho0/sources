@extends('admin.layouts.app')
@section('title','Setting')
@section('styles')

@stop
@section('content')

<div class="container-fluid">

  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Departments</h6>
    </div>
    <div class="card-body">
    </div>
  </div>

</div>
@endsection
@section('scripts')

@stop