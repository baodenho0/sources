@extends("website.layouts.master")
@section('content')
<div class="ro-section ro-padding-top">
    <div class="container">
        <div class="row">
            {!!$data->description!!}
        </div>
    </div>
</div>
@endsection
